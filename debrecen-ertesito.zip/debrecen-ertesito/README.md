# Debrecen ingatlan- és árverésfigyelő

Óránként ellenőrzi a következő oldalakat, és emailt küld, ha **új** hirdetés
jelenik meg Debrecenben (telek, csarnok/ipari ingatlan) vagy Debrecent érintő
állami ingatlanárverés van:

- ingatlan.com (telek + ipari ingatlan)
- Jófogás (telek + ipari ingatlan/üzlethelyiség)
- Ingatlanok.hu (ipari ingatlan)
- Elektronikus Aukciós Rendszer (e-arveres.mnv.hu) - állami árverések

## Telepítés (kb. 10 perc, egyszer kell megcsinálni)

### 1. Töltsd fel ezt a mappát egy GitHub repóba

1. Jelentkezz be a https://github.com oldalon a saját fiókoddal.
2. Kattints jobb fent a **"+"** ikonra → **"New repository"**.
3. Nevezd el pl. `debrecen-ertesito`, állítsd **Public**-ra (az ingyenes
   Actions-höz ez a legegyszerűbb), majd **"Create repository"**.
4. A megjelenő oldalon kattints az **"uploading an existing file"** linkre,
   és húzd be ide az összes fájlt ebből a mappából (a `.github` mappástul,
   mappa-struktúra megtartásával — ha a böngésző nem engedi mappástul
   feltölteni, használd a "Add file" → "Upload files" funkciót, vagy
   telepítsd a `git` parancssori eszközt és `git push`-old fel).

### 2. Add meg a "secret"-eket (titkosan tárolt beállítások)

A repódban:
1. **Settings** fül → bal oldalon **Secrets and variables** → **Actions**
2. **"New repository secret"** gombbal add hozzá egyenként:
   - `GMAIL_USER` → `debrecen.ingatlan.ertesito@gmail.com`
   - `GMAIL_APP_PASSWORD` → a 16 karakteres app jelszó, amit korábban
     generáltál (szóközök nélkül is jó)
   - `TO_EMAIL` → `csordas.adam2006@gmail.com`

### 3. Ellenőrizd, hogy fut-e

1. A repódban menj az **Actions** fülre.
2. Kattints a **"Debrecen ingatlan/árverés figyelő"** workflow-ra.
3. Jobb oldalt **"Run workflow"** → **"Run workflow"** — ezzel azonnal
   lefuttathatod, nem kell várni az óráig.
4. Pár másodperc múlva frissítsd az oldalt, kattints a lefutott futtatásra,
   nézd meg a logot: ott látod, hány hirdetést talált, és próbált-e emailt
   küldeni.

Ha minden jó, mostantól **óránként automatikusan lefut**, a te géped
bekapcsolása nélkül is.

## Ha egy oldal formátuma megváltozik

Az ingatlanos oldalak időnként átalakítják a weboldalukat, emiatt előfordulhat,
hogy egy adott portál egy idő után nem ad több találatot, vagy hibát ír a
logba. Ez nem hiba a szkriptedben, hanem azt jelenti, hogy az adott oldal
HTML-je megváltozott, és a keresőmintát (`id_regex`) frissíteni kell a
`scraper.py`-ban. Szólj, és segítek frissíteni.

## Új keresés hozzáadása

A `scraper.py` tetején lévő `SITES` listában bármikor hozzáadhatsz új
keresést: másold be egy meglévő bejegyzés mintáját, írd be az új keresés
URL-jét, és — ha szükséges — a hirdetés-linkek felismeréséhez való regex-et.
